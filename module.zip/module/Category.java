package module;

public enum Category {
	
	COMBAT, MOVEMENT, PLAYER, RENDER, MISC, GHOST

}
